# Thunder Chat (natywny, Rust + egui)

Budowanie (Windows):
    rustup default stable
    cargo run --release
Gotowy plik: target/release/thunder-chat.exe
